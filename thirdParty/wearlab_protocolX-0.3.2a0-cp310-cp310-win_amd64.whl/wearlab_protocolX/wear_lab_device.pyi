# wear_lab_device.pyi
import socket
import threading
from typing import Any, Callable, List
from .meta import PackageType, Command, ResearchData, DeviceMeta, HardwareDiscoveryPacket, EmgDataPacket, IMUDataPacket


class WearLabDevice:
    def __init__(self, model: int, ip: str, tcp_port: int, hardware_identifier: str,
                 connection_type: str = "WLAN") -> None:
        self.ip: str
        self.tcp_port: int
        self.tcp_socket: socket.socket
        self.hardware_identifier: str
        self.connection_type: str
        self.running: bool
        self.connected: bool
        self.battery_voltage: float
        self.hardware_revision: str
        self.model: int
        self.firmware_version: str
        self.__display_name: str

    def register_disconnect_callback(self, callback: Callable[["WearLabDevice"], None]) -> None:
        pass

    def unregister_disconnect_callback(self, callback: Callable[["WearLabDevice"], None]) -> bool:
        pass

    @property
    def display_name(self) -> str:
        return ""

    @display_name.setter
    def display_name(self, value: str) -> None:
        pass

    @property
    def battery_level(self) -> float:
        return 0.0

    def start_communication(self) -> None:
        pass

    def set_hardware_info(self, hardware_info: HardwareDiscoveryPacket) -> None:
        pass

    def send_tcp_data(self, command: PackageType, *args: Any) -> None:
        pass

    def stop_tcp_connection(self) -> None:
        pass


class CallBackFunction:
    def __init__(self, callback: Callable[["WearLabDevice", Any], None], *args: Any) -> None:
        self.callback: Callable[["WearLabDevice", Any], None]
        self.args: tuple


class DeviceCommunication:
    def __new__(cls) -> "DeviceCommunication":
        pass

    def __init__(self, udp_ip: str = '0.0.0.0', udp_port: int = 6977, tcp_ip: str = '127.0.0.1',
                 tcp_port: int = 5603) -> None:
        self.udp_ip: str
        self.udp_port: int
        self.tcp_ip: str
        self.tcp_port: int
        self.udp_socket: socket.socket
        self.devices: dict
        self.udp_thread: threading.Thread
        self.running: bool
        self.udp_cache: bytes

    def register_device_connect_callback(self, callback: Callable[["WearLabDevice", Any], None], *args: Any) -> None:
        """
        注册设备连接信息回调
        Args:
            callback:
            *args:

        Returns:

        """
        pass

    def unregister_device_connect_callback(self, callback: Callable[["WearLabDevice", Any], None]) -> bool:
        pass

    def register_device_disconnect_callback(self, callback: Callable[["WearLabDevice", Any], None], *args: Any) -> None:
        pass

    def unregister_device_disconnect_callback(self, callback: Callable[["WearLabDevice", Any], None]) -> bool:
        pass

    def register_device_discovery_callback(self, callback: Callable[["WearLabDevice", Any], None], *args: Any) -> None:
        pass

    def unregister_device_discovery_callback(self, callback: Callable[["WearLabDevice", Any], None]) -> bool:
        pass

    def register_data_change_callback(self, callback: Callable[["ResearchData", Any], None], *args: Any) -> None:
        pass

    def unregister_data_change_callback(self, callback: Callable[["ResearchData", Any], None]) -> bool:
        pass

    def start_communication(self) -> None:
        pass

    def stop_communication(self) -> None:
        pass

    def connect_device(self, hardware_identifier: str) -> None:
        pass

    def send_command(self, hardware_identifier: str, command: Command, *args: Any) -> None:
        pass

    def disconnect_device(self, hardware_identifier: str) -> None:
        pass


