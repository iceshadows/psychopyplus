# meta.pyi
import ctypes
import json
import os
import struct
import sys
import numpy as np
from collections import defaultdict
from typing import List

class DeviceInfo:
    display_name: str
    model: str
    platform: str
    manufacturer: str

    def __init__(self, info: dict) -> None:
        pass

class Sensor:
    package_type: str
    sensor_type: str
    group: str
    is_3d_position: bool
    channel_num: int
    available_pga: int
    available_sampling_rates: float
    unit: str
    resolution: float
    physical_minimum: float
    physical_maximum: float

    def __init__(self, sensor: dict) -> None:
        pass

class Communication:
    wireless: List[Wireless]
    wired: str

    def __init__(self, comm: dict) -> None:
        pass

class Wireless:
    type: str
    version: str
    pairing_mode: str

    def __init__(self, wireless: dict) -> None:
        pass

class Battery:
    capacity: float
    minimum_voltage: float
    maximum_voltage: float
    battery_life: float
    charging_time: float
    charging_method: str

    def __init__(self, battery: dict) -> None:
        pass

    def voltage_to_percentage(self, current_voltage: float) -> float:
        pass

class DataStorage:
    internal_memory: int
    expandable_memory: int
    cloud_sync: bool

    def __init__(self, storage: dict) -> None:
        pass

class Certification:
    certification_type: str
    certification_date: str

    def __init__(self, cert: dict) -> None:
        pass

class Software:
    operating_system: str
    supported_platforms: List[str]
    update_policy: 'UpdatePolicy'

    def __init__(self, software: dict) -> None:
        pass

class UpdatePolicy:
    ota_support: bool
    update_url: str

    def __init__(self, policy: dict) -> None:
        pass

class DeviceCapabilities:
    sensors: List[Sensor]
    communication: Communication
    battery: Battery
    data_storage: DataStorage
    features: List[str]

    def __init__(self, capabilities: dict) -> None:
        pass

class DeviceMeta:
    device_info: DeviceInfo
    capabilities: DeviceCapabilities
    certifications: List[Certification]
    software: Software

    def __init__(self, device: dict) -> None:
        pass

class DeviceMetaLib:
    devices: dict

    def __init__(self) -> None:
        pass

    def __read_device_info(self) -> dict:
        pass

    def get_device_meta(self, device_model: str) -> DeviceMeta:
        pass

class Command:
    name: str
    packageType: int
    parmTypes: List[type]

    def __init__(self, name: str, packageType: int, parmTypes: List[type] = []) -> None:
        pass

    def __str__(self) -> str:
        pass

    def __eq__(self, other: 'Command' | str | int) -> bool:
        pass

    def to_bytes(self, *args: List) -> bytes:
        pass

class PackageType:
    Reboot: Command
    PowerOff: Command
    Reset: Command
    Beep: Command
    Blink: Command
    Rename: Command
    ReqHardwareInfo: Command
    CaliGyro: Command
    CaliMagn: Command
    WifiDisconnect: Command
    SetCycleIMU: Command
    SetCycleMagn: Command
    RawMagnData: int
    ImuData: int
    HardwareInfo: int
    RunStatus: int
    SetADCMode: int
    SetADCPGA: int
    ReqActivation: int
    ReqDownload: int
    EmgData16: int
    EmgData64: int
    ImpedanceData16: int
    ImpedanceData64: int
    EmgData2: int
    ImpedanceData2: int
    PING: Command

class ResearchData:
    hardware_identifier: str
    package_type: int
    pack_time: str

    def __init__(self, hardware_identifier: str, package_type: int, pack_time: str) -> None:
        pass

class EmgDataPacket(ResearchData):
    emg_data: np.ndarray

    def __init__(self, hardware_identifier: str, package_type: int, pack_time: str, emg_data: np.ndarray) -> None:
        pass

    @classmethod
    def from_bytes(cls, data: bytes, hardware_identifier: str, pack_time: str) -> 'EmgDataPacket':
        pass

    def __str__(self) -> str:
        pass

class IMUDataPacket(ResearchData):
    quat: ctypes.c_float * 4
    gyro: ctypes.c_float * 3
    accl: ctypes.c_float * 3
    magn: ctypes.c_float * 3

    def __init__(self, hardware_identifier: str, package_type: int, pack_time: str, quat: ctypes.c_float, gyro: ctypes.c_float, accl: ctypes.c_float, magn: ctypes.c_float) -> None:
        pass

    @classmethod
    def from_bytes(cls, data: bytes, hardware_identifier: str, pack_time: str) -> 'IMUDataPacket':
        pass

    def __str__(self) -> str:
        pass

class HardwareDiscoveryPacket(ResearchData):
    display_name: str
    model: int
    manufacturer: str
    hardware_revision: str
    firmware_version: str
    mcu_temp: float
    battery_voltage: float

    def __init__(self, hardware_identifier: str, pack_time: str, display_name: str, model: int, manufacturer: str, hardware_revision: str, firmware_version: str, mcu_temp: float, battery_voltage: float) -> None:
        pass

    @classmethod
    def from_bytes(cls, data: bytes, hardware_identifier: str, pack_time: str) -> 'HardwareDiscoveryPacket':
        pass

    def to_bytes(self) -> bytes:
        pass

    def __str__(self) -> str:
        pass

# 示例调用
if __name__ == "__main__":
    device_support = DeviceMetaLib()
    meta = device_support.get_device_meta(0)
    print(meta.capabilities.battery.voltage_to_percentage(3.7))
